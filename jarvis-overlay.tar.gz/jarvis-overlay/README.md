# 🧠 AI Central — J.A.R.V.I.S Desktop Overlay

A J.A.R.V.I.S-style Windows 11 desktop overlay that shows your AI system status,
3D system diagram, agent connections, and agenda — right on your desktop.

## ✨ Features

- **Always-on-top** — floats above other windows
- **Frameless glass UI** — clean J.A.R.V.I.S aesthetic
- **System tray** — sits in tray when minimized
- **Hotkeys** — `Ctrl+Alt+A` or `Ctrl+Alt+J` to toggle
- **Live system info** — CPU, RAM, Disk, Uptime
- **3D System Diagram** — toggle to see the full AI Central mind map
- **Agenda** — upcoming events from your calendar
- **Agent status** — online/offline for all 3 AI agents

## 📦 Build Instructions (Windows 11)

### Prerequisites
1. Install **Node.js** (v18+): https://nodejs.org/
2. Install **Git**: https://git-scm.com/ (optional)

### Build

```bash
# 1. Extract the project
unzip jarvis-overlay.zip

# 2. Install dependencies
cd jarvis-overlay
npm install

# 3. Build the installer
npm run build:win
```

The installer will be in `dist/` folder:
- `JARVIS-Overlay-Setup-1.0.0.exe`

### Quick Start (no build)
```bash
# Just run the dev version
npm start
```

### Run on Windows startup
After installation:
1. Right-click the tray icon → Settings
2. Or create a shortcut in `shell:startup`

## ⌨️ Hotkeys

| Key | Action |
|-----|--------|
| `Ctrl+Alt+A` | Toggle overlay |
| `Ctrl+Alt+J` | Toggle overlay |
| `─` (title bar) | Minimize to tray |
| `✕` (title bar) | Hide to tray |

## 🎨 Design

- Dark glass background with blur
- Scan line CRT overlay
- Pulsing status indicators
- Animated voice bar
- Rotating J.A.R.V.I.S rings
- Monospace HUD-style typography

## 📁 Project Structure

```
jarvis-overlay/
├── package.json          # Electron + build config
├── main.js               # Electron main process
├── preload.js            # Secure bridge
├── renderer/
│   ├── index.html        # J.A.R.V.I.S UI
│   ├── jarvis.css        # Styling
│   └── jarvis.js         # Logic
└── assets/
    └── icon.png          # App icon
```

## 🔧 Configuration

Edit `main.js` to change:
- Window size (`width`, `height`)
- Position (`x`, `y`)
- Hotkey bindings (`globalShortcut.register`)
