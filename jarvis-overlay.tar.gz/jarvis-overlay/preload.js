const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  minimize: () => ipcRenderer.send('minimize'),
  close: () => ipcRenderer.send('close'),
  resizeWindow: (w, h) => ipcRenderer.send('resize-window', { width: w, height: h }),
});
