// ── Clock ────────────────────────────────────
function updateClock() {
  const now = new Date();
  const h = String(now.getHours()).padStart(2,'0');
  const m = String(now.getMinutes()).padStart(2,'0');
  const s = String(now.getSeconds()).padStart(2,'0');
  document.getElementById('time-display').textContent = h+':'+m+':'+s;
  
  const days = ['SUN','MON','TUE','WED','THU','FRI','SAT'];
  const months = ['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];
  document.getElementById('date-display').textContent = 
    days[now.getDay()] + ' ' + 
    String(now.getDate()).padStart(2,'0') + ' ' + 
    months[now.getMonth()] + ' ' + 
    now.getFullYear();
}
setInterval(updateClock, 1000);
updateClock();

// ── System info (via fetch from AI Central) ──
async function fetchSysInfo() {
  try {
    const resp = await fetch('https://ai-central.kinet-poc.com/api/system/status');
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const data = await resp.json();
    document.getElementById('cpu').textContent = (data.cpu || '—') + '%';
    document.getElementById('ram').textContent = (data.memory || '—') + '%';
    document.getElementById('disk').textContent = (data.disk || '—') + '%';
    document.getElementById('uptime').textContent = data.uptime || '—';
  } catch(e) {
    // Fallback: simulate local system info
    document.getElementById('cpu').textContent = Math.round(Math.random() * 40 + 10) + '%';
    document.getElementById('ram').textContent = Math.round(Math.random() * 30 + 40) + '%';
    document.getElementById('disk').textContent = Math.round(Math.random() * 10 + 68) + '%';
    document.getElementById('uptime').textContent = Math.floor(Math.random() * 12 + 5) + 'd';
    document.getElementById('status-msg').textContent = '◉ OFFLINE — LOCAL MODE';
    document.getElementById('status-msg').style.color = '#eab308';
  }
}
fetchSysInfo();
setInterval(fetchSysInfo, 30000);

// ── Agenda (fetch from AI Central) ───────────
async function fetchAgenda() {
  try {
    const resp = await fetch('https://ai-central.kinet-poc.com/api/agenda/today');
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const data = await resp.json();
    const list = document.getElementById('agenda');
    if (data.events && data.events.length > 0) {
      list.innerHTML = data.events.slice(0, 3).map(e => 
        '<div class="agenda-item"><span class="time">' + (e.time||'—') + '</span><span class="evt">' + (e.title||'—') + '</span></div>'
      ).join('');
    }
  } catch(e) {
    // Keep default "No upcoming events"
  }
}
fetchAgenda();

// ── Weather (fetch from AI Central) ──────────
async function fetchWeather() {
  try {
    const resp = await fetch('https://ai-central.kinet-poc.com/api/weather/current');
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const data = await resp.json();
    document.getElementById('weather').textContent = 
      (data.temp || '—') + '°C ' + (data.condition || '');
  } catch(e) {
    document.getElementById('weather').textContent = '—°C offline';
  }
}
fetchWeather();

// ── Animated status messages ─────────────────
const statusMsgs = [
  '◉ ALL SYSTEMS NOMINAL',
  '◉ MONITORING 23 AGENTS',
  '◉ CONNECTION STABLE',
  '◉ READY FOR DEPLOYMENT',
  '◉ SYSTEM DIAGNOSTICS OK',
];
let msgIdx = 0;
setInterval(() => {
  msgIdx = (msgIdx + 1) % statusMsgs.length;
  const el = document.getElementById('status-msg');
  if (!el.textContent.includes('OFFLINE')) {
    el.textContent = statusMsgs[msgIdx];
  }
}, 5000);

// ── Drag window (via titlebar) ───────────────
// Electron handles -webkit-app-region: drag on titlebar
// No extra code needed
