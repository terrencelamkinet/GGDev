const { app, BrowserWindow, globalShortcut, Tray, Menu, ipcMain, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow = null;
let tray = null;
let isVisible = true;

// ── Create window ────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 480,
    height: 560,
    x: 100,
    y: 100,
    frame: false,
    transparent: false,
    alwaysOnTop: true,
    skipTaskbar: false,
    resizable: false,
    hasShadow: false,
    backgroundColor: '#0f0f1a',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: false
    }
  });

  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
  
  // Stay on top always
  mainWindow.setAlwaysOnTop(true, 'screen-saver');

  // Remove menu
  mainWindow.setMenu(null);

  // Click-through on transparent areas (for future transparent mode)
  // mainWindow.setIgnoreMouseEvents(true, { forward: true });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// ── Tray icon (system tray) ──────────────────────
function createTray() {
  // Create a simple 16x16 tray icon from nativeImage
  const iconSize = 16;
  const canvas = Buffer.alloc(iconSize * iconSize * 4);
  // Simple blue dot (will be replaced with proper icon)
  for (let y = 0; y < iconSize; y++) {
    for (let x = 0; x < iconSize; x++) {
      const idx = (y * iconSize + x) * 4;
      canvas[idx] = 37;     // R
      canvas[idx+1] = 99;   // G
      canvas[idx+2] = 235;  // B
      canvas[idx+3] = 255;  // A
    }
  }
  const img = nativeImage.createFromBuffer(canvas, { width: iconSize, height: iconSize });
  
  tray = new Tray(img);
  tray.setToolTip('AI Central — J.A.R.V.I.S');
  
  const contextMenu = Menu.buildFromTemplate([
    { label: 'Show/Hide', click: toggleVisibility },
    { type: 'separator' },
    { label: 'Quit', click: () => { app.isQuitting = true; app.quit(); } }
  ]);
  
  tray.setContextMenu(contextMenu);
  tray.on('click', toggleVisibility);
}

function toggleVisibility() {
  if (!mainWindow) return;
  if (isVisible) {
    mainWindow.hide();
    isVisible = false;
  } else {
    mainWindow.show();
    mainWindow.focus();
    isVisible = true;
  }
}

// ── IPC ──────────────────────────────────────────
ipcMain.on('minimize', () => {
  if (mainWindow) mainWindow.minimize();
});

ipcMain.on('close', () => {
  if (mainWindow) mainWindow.hide();
});

ipcMain.on('resize-window', (event, { width, height }) => {
  if (mainWindow) {
    mainWindow.setSize(width, height);
  }
});

// ── App lifecycle ────────────────────────────────
app.whenReady().then(() => {
  createWindow();
  createTray();

  // Global hotkey: Ctrl+Alt+A to toggle
  globalShortcut.register('CommandOrControl+Alt+A', toggleVisibility);
  
  // Ctrl+Alt+J for J.A.R.V.I.S
  globalShortcut.register('CommandOrControl+Alt+J', toggleVisibility);
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    // Don't quit - keep in tray
  }
});

app.on('before-quit', () => {
  app.isQuitting = true;
});

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});
