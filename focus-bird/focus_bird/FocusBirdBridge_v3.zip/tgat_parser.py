"""
TGAT Protocol Parser — Pure Python replacement for BrainLinkParser.pyd
======================================================================
Parses ThinkGear TGAT packets from BrainLink Pro / NeuroSky devices.
No compiled .pyd required — works on any Python 3.x.

Packet format:
  [0xAA, 0xAA, pkt_len, payload..., checksum, 0x23, 0x23]

Payload codes:
  0x02 = Poor Signal Quality (1 byte)
  0x04 = eSense Attention (1 byte)
  0x05 = eSense Meditation (1 byte)
  0x80 = Raw EEG wave (2 bytes, big-endian signed)
  0x83 = EEG power bands (8×3=24 bytes)
"""

import struct


class TGATEegData:
    """Simulates the .pyd callback data object — uses getattr pattern."""
    def __init__(self):
        self.signal = -1
        self.attention = -1
        self.meditation = -1
        self.delta = 0
        self.theta = 0
        self.lowAlpha = 0
        self.highAlpha = 0
        self.lowBeta = 0
        self.highBeta = 0
        self.lowGamma = 0
        self.highGamma = 0
        self.raw = 0


class TGATExtData:
    """Extended data object (battery, version, etc.)"""
    def __init__(self):
        self.battery = -1
        self.version = -1


def parse_packet(pkt: bytes):
    """
    Parse a single TGAT packet.
    Returns (eeg_data, ext_data) — eeg_data is always present, ext_data may be None.
    """
    eeg = TGATEegData()
    ext = TGATExtData()
    has_ext = False

    if len(pkt) < 4:
        return eeg, None
    if pkt[0] != 0xAA or pkt[1] != 0xAA:
        return eeg, None

    pkt_len = pkt[2]
    if len(pkt) < 3 + pkt_len + 1:
        return eeg, None

    payload = pkt[3:3 + pkt_len]
    checksum = pkt[3 + pkt_len]

    # Verify checksum (two methods — try both)
    c1 = (~sum(pkt[2:3 + pkt_len])) & 0xFF
    c2 = (~sum(payload)) & 0xFF
    if checksum != c1 and checksum != c2:
        return eeg, None

    # Parse payload
    i = 0
    while i < len(payload):
        code = payload[i]
        i += 1

        if code == 0x00:
            continue  # filler byte

        elif code == 0x01:
            # One-byte code with 0 length
            continue

        elif code == 0x02:
            # Poor Signal Quality (1 byte)
            if i < len(payload):
                eeg.signal = payload[i]
                i += 1

        elif code == 0x04:
            # eSense Attention (1 byte)
            if i < len(payload):
                eeg.attention = payload[i]
                i += 1

        elif code == 0x05:
            # eSense Meditation (1 byte)
            if i < len(payload):
                eeg.meditation = payload[i]
                i += 1

        elif code == 0x80:
            # Raw EEG wave (2 bytes, big-endian signed)
            if i + 1 < len(payload):
                eeg.raw = struct.unpack('>h', payload[i:i+2])[0]
                i += 2

        elif code == 0x83:
            # EEG power bands (8×3=24 bytes)
            if i + 23 < len(payload):
                eeg.delta = (payload[i] << 16) | (payload[i+1] << 8) | payload[i+2]
                eeg.theta = (payload[i+3] << 16) | (payload[i+4] << 8) | payload[i+5]
                eeg.lowAlpha = (payload[i+6] << 16) | (payload[i+7] << 8) | payload[i+8]
                eeg.highAlpha = (payload[i+9] << 16) | (payload[i+10] << 8) | payload[i+11]
                eeg.lowBeta = (payload[i+12] << 16) | (payload[i+13] << 8) | payload[i+14]
                eeg.highBeta = (payload[i+15] << 16) | (payload[i+16] << 8) | payload[i+17]
                eeg.lowGamma = (payload[i+18] << 16) | (payload[i+19] << 8) | payload[i+20]
                eeg.highGamma = (payload[i+21] << 16) | (payload[i+22] << 8) | payload[i+23]
                i += 24
                has_ext = True

        elif code & 0x80:
            # Multi-byte codes: consume length byte first
            if i < len(payload):
                length = payload[i]
                i += 1
                if i + length <= len(payload):
                    # Skip unknown multi-byte data
                    i += length
                else:
                    break
        else:
            # Single-byte unknown — skip
            pass

    return eeg, ext if has_ext else None


class BrainLinkParser:
    """
    Pure Python BrainLinkParser — drop-in replacement for BrainLinkParser.pyd.
    Usage:
        parser = BrainLinkParser()
        parser.parse(bytes_data)  # feeds raw TGAT bytes
    """

    def __init__(self, eeg_callback=None, eeg_extend_callback=None,
                 gyro_callback=None, raw_callback=None, rr_callback=None,
                 **kwargs):
        self._buf = bytearray()
        self.eeg_cb = eeg_callback
        self.ext_cb = eeg_extend_callback
        # Accept alternative parameter names from the .pyd
        if self.eeg_cb is None:
            for k, v in kwargs.items():
                lower = k.replace('_', '').replace('-', '').lower()
                if 'eeg' in lower and 'callback' in lower:
                    self.eeg_cb = v
                elif 'extend' in lower or 'ext' in lower:
                    self.ext_cb = v

    def parse(self, data: bytes):
        """Feed raw bytes from serial. Calls eeg_callback for every parsed packet."""
        if not data:
            return
        self._buf.extend(data)

        while len(self._buf) >= 4:
            # Sync to 0xAA 0xAA header
            if self._buf[0] != 0xAA or self._buf[1] != 0xAA:
                self._buf.pop(0)
                continue

            pkt_len = self._buf[2]
            total = 3 + pkt_len + 1  # header(3) + payload + checksum(1)

            if len(self._buf) < total:
                break  # need more data

            pkt = bytes(self._buf[:total])
            self._buf = self._buf[total:]

            eeg, ext = parse_packet(pkt)

            if self.eeg_cb:
                self.eeg_cb(eeg)
            if self.ext_cb and ext is not None:
                self.ext_cb(ext)
