@echo off
chcp 65001 >nul
echo ================================================
echo   Focus Bird Pro - BrainLink Bridge (Relay Mode)
echo ================================================
echo.

echo Scanning COM ports...
python -c "import serial.tools.list_ports; [print('  '+p.device+'  '+p.description) for p in serial.tools.list_ports.comports()]" 2>nul
echo.

set /p PORT=Enter COM port (e.g. COM3):
if "%PORT%"=="" set PORT=COM3

echo.
echo Starting bridge on %PORT% with RELAY mode...
echo Target: wss://brainlink.kinet-poc.com/brainlink
echo.

py -3.11 brainlink_pro.py --port %PORT% --relay
if %ERRORLEVEL% NEQ 0 (
    echo Python 3.11 not found. Trying default Python...
    python brainlink_pro.py --port %PORT% --relay
)

pause
