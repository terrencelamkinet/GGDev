@echo off
chcp 65001 >nul
echo ================================================
echo   Focus Bird Pro - Windows Bridge (one-time setup)
echo ================================================
echo.

echo Step 1: Check Python 3.11
py -3.11 --version
if %ERRORLEVEL% NEQ 0 (
    echo [WARN] Python 3.11 not found.
    echo Install Python 3.11 from: https://www.python.org/downloads/release/python-3119/
    echo Or continue with default Python...
)
echo.

echo Step 2: Install dependencies
pip install pyserial websockets
echo.

echo Step 3: Scan COM ports for BrainLink
python -c "import serial.tools.list_ports; [print('  '+p.device+'  '+p.description) for p in serial.tools.list_ports.comports()]"
echo.
echo Tip: BrainLink Pro has TWO COM ports - pick the OUTPUT one
echo.
echo === Done! ===
echo Now run: start_bridge.bat
echo.
pause
