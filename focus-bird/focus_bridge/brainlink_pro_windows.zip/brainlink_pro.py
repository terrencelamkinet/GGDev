#!/usr/bin/env python3
"""
BrainLink Pro 腦波讀取器 — Windows 版（官方 SDK）
=================================================
直接用 pyserial，唔需要 cushy_serial。

流程：
  1. Windows 藍牙配對 BrainLink Pro（揀有耳機圖示嗰個）
  2. 系統會開兩個 COM port（input + output）
  3. 揀 OUTPUT port 連接（唔係 input！）

用法：
  # 掃描 COM port
  python brainlink_pro.py --scan

  # 連接指定 port
  python brainlink_pro.py --port COM5

  # 連接 + 輸出 JSON（俾其他程式食）
  python brainlink_pro.py --port COM5 --json

  # 連接 + WebSocket 俾 Focus Bird
  python brainlink_pro.py --port COM5 --ws 8765

Requires: Python 3.11, pyserial, BrainLinkParser.pyd
"""

import argparse
import json
import sys
import time
import struct
from datetime import datetime

try:
    from BrainLinkParser import BrainLinkParser
except ImportError:
    print("ERROR: 請下載 BrainLinkParser.pyd 放喺同一個 folder")
    print("下載: https://github.com/Macrotellect/BrainLinkParser-Python")
    print("或者: https://o.macrotellect.com/index.html#v1")
    sys.exit(1)

try:
    import serial
    import serial.tools.list_ports
except ImportError:
    print("ERROR: 請安裝 pyserial: pip install pyserial")
    sys.exit(1)


# ── Callbacks ──

class BrainData:
    """Latest brainwave data state."""
    def __init__(self):
        self.attention = 0
        self.meditation = 0
        self.signal = 200  # 200 = disconnected
        self.delta = 0
        self.theta = 0
        self.low_alpha = 0
        self.high_alpha = 0
        self.low_beta = 0
        self.high_beta = 0
        self.low_gamma = 0
        self.high_gamma = 0
        self.battery = -1
        self.focus_level = 0.0
        self.timestamp = 0.0

    def to_dict(self):
        return {
            "attention": self.attention,
            "meditation": self.meditation,
            "signal": self.signal,
            "delta": self.delta,
            "theta": self.theta,
            "lowAlpha": self.low_alpha,
            "highAlpha": self.high_alpha,
            "lowBeta": self.low_beta,
            "highBeta": self.high_beta,
            "lowGamma": self.low_gamma,
            "highGamma": self.high_gamma,
            "battery": self.battery,
            "focus": self.focus_level,
            "timestamp": self.timestamp,
        }


state = BrainData()


def on_eeg(data):
    """EEG data callback — called on every valid brainwave packet."""
    state.attention = getattr(data, 'attention', 0) or 0
    state.meditation = getattr(data, 'meditation', 0) or 0
    state.signal = getattr(data, 'signal', 200) or 200
    state.timestamp = time.time()

    # Compute focus level (simple ratio)
    if state.signal < 150:  # Good signal quality
        state.focus_level = round(state.attention / 100.0, 2)
    else:
        state.focus_level = 0.0


def on_extend_eeg(data):
    """Extended EEG data callback — band powers + battery."""
    state.delta = getattr(data, 'delta', 0) or 0
    state.theta = getattr(data, 'theta', 0) or 0
    state.low_alpha = getattr(data, 'lowAlpha', 0) or 0
    state.high_alpha = getattr(data, 'highAlpha', 0) or 0
    state.low_beta = getattr(data, 'lowBeta', 0) or 0
    state.high_beta = getattr(data, 'highBeta', 0) or 0
    state.low_gamma = getattr(data, 'lowGamma', 0) or 0
    state.high_gamma = getattr(data, 'highGamma', 0) or 0
    state.battery = getattr(data, 'battery', -1) or -1


def on_gyro(x, y, z):
    pass  # 唔用 gyro


def on_rr(rr1, rr2, rr3):
    pass  # 唔用心率


def on_raw(raw):
    pass  # 唔用 raw


# ── Serial reader ──

def read_serial(port, baud=115200, output_json=False, ws_port=None):
    """Connect to BrainLink via serial Bluetooth COM port and read data."""
    parser = BrainLinkParser(
        eeg_callback=on_eeg,
        eeg_extend_callback=on_extend_eeg,
        gyro_callback=on_gyro,
        rr_callback=on_rr,
        raw_callback=on_raw,
    )

    print(f"連接 BrainLink Pro 到 {port} @ {baud}...")
    ser = serial.Serial(port, baud, timeout=1)

    # Wait for device to stabilize
    ser.reset_input_buffer()
    print(f"✓ 已連接！等待數據...")
    print(f"  訊號強度: <50=最佳, 50-150=可用, >150=弱/斷線")
    print("─" * 50)

    # Optional WebSocket server
    ws_server = None
    clients = set()
    if ws_port:
        import asyncio
        import websockets

        async def ws_handler(websocket):
            clients.add(websocket)
            try:
                async for _ in websocket:
                    pass
            finally:
                clients.discard(websocket)

        async def ws_broadcast():
            while True:
                if clients:
                    payload = json.dumps(state.to_dict())
                    dead = set()
                    for ws in clients:
                        try:
                            await ws.send(payload)
                        except:
                            dead.add(ws)
                    clients -= dead
                await asyncio.sleep(0.1)

        async def start_ws():
            nonlocal ws_server
            ws_server = await websockets.serve(ws_handler, "0.0.0.0", ws_port)
            print(f"WebSocket server: ws://0.0.0.0:{ws_port}")
            await ws_broadcast()

        import threading
        ws_thread = threading.Thread(target=lambda: asyncio.run(start_ws()), daemon=True)
        ws_thread.start()

    # Main read loop
    buffer = bytearray()
    last_output = 0

    try:
        while True:
            if ser.in_waiting:
                chunk = ser.read(ser.in_waiting)
                buffer.extend(chunk)

                # Parse complete packets
                while len(buffer) >= 4:
                    # Look for packet header 0xAA 0xAA
                    if buffer[0] != 0xAA or buffer[1] != 0xAA:
                        buffer.pop(0)
                        continue

                    if len(buffer) < 4:
                        break

                    pkt_len = buffer[3]
                    total_len = 4 + pkt_len + 1  # header(4) + data + checksum

                    if len(buffer) < total_len:
                        break

                    packet = bytes(buffer[:total_len])
                    buffer = buffer[total_len:]

                    try:
                        parser.parse(packet)
                    except Exception:
                        pass  # Malformed packet, skip

                # Output
                now = time.time()
                if now - last_output >= 0.5:  # 2 updates/sec
                    last_output = now

                    if output_json:
                        print(json.dumps(state.to_dict()), flush=True)
                    else:
                        sig_bar = "█" * max(0, 5 - state.signal // 30) + "░" * min(5, state.signal // 30)
                        print(
                            f"\r注意:{state.attention:>3} "
                            f"放鬆:{state.meditation:>3} "
                            f"訊號:[{sig_bar}] {state.signal:>3} "
                            f"電量:{'N/A' if state.battery < 0 else str(state.battery)+'%':>4} "
                            f"β:{state.low_beta:>5} γ:{state.low_gamma:>5}",
                            end="", flush=True
                        )

            else:
                time.sleep(0.01)

    except KeyboardInterrupt:
        print("\n\n已中斷。")
    finally:
        ser.close()


def scan_ports():
    """Scan and display available COM ports."""
    ports = serial.tools.list_ports.comports()
    if not ports:
        print("沒有發現任何 COM port。")
        print("請先喺 Windows 藍牙設定配對 BrainLink Pro。")
        return

    print("可用 COM Port:")
    print("─" * 60)
    for p in sorted(ports, key=lambda x: x.device):
        is_bluetooth = "bluetooth" in p.description.lower() or "bt" in p.description.lower()
        tag = "🔵 BT" if is_bluetooth else "   "
        print(f"  {tag} {p.device:6s} — {p.description}")
    print("─" * 60)
    print("💡 BrainLink Pro 會出現兩個 COM port：")
    print("   揀 OUTPUT port（唔係 INPUT）")
    print("   去 藍牙設定 > 更多藍牙選項 > COM 端口 檢查邊個係 Output")
    print()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="BrainLink Pro EEG 讀取器")
    parser.add_argument("--port", help="COM port (e.g. COM5)")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--scan", action="store_true", help="掃描可用 COM port")
    parser.add_argument("--json", action="store_true", help="輸出 JSON 格式")
    parser.add_argument("--ws", type=int, help="啟動 WebSocket server port")
    args = parser.parse_args()

    if args.scan:
        scan_ports()
        sys.exit(0)

    if not args.port:
        print("用法：")
        print("  python brainlink_pro.py --scan              # 掃描 COM port")
        print("  python brainlink_pro.py --port COM5         # 連接 BrainLink")
        print("  python brainlink_pro.py --port COM5 --json  # JSON 輸出")
        print("  python brainlink_pro.py --port COM5 --ws 8765  # WebSocket")
        sys.exit(1)

    read_serial(args.port, args.baud, args.json, args.ws)
